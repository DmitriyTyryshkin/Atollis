import torch
import torch.nn as nn


class LinNet(nn.Module):
    def __init__(self):
        super().__init__()

        self.act = nn.LeakyReLU(0.2)
        self.linear0 = nn.Linear(9802, 16)
        self.linear2 = nn.Linear(16, 35)

    def forward(self, x):
        x = x.to(torch.float32)

        out = self.linear0(x)
        out = self.act(out)

        out = self.linear2(out)
        out = self.act(out)

        return out
