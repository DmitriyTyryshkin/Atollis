import re
import pymorphy2
import torch
import _pickle as pickle

from AdClassificationPackage.model import LinNet

regex = re.compile("[А-Яа-я:=!\)\()A-z\_\%/|]+")


def words_only(text, regex=regex):
    try:
        return regex.findall(text)
    except:
        return []


def lemmatize(text, pymorphy=pymorphy2.MorphAnalyzer()):
    try:
        return " ".join([pymorphy.parse(w)[0].normal_form for w in text])
    except:
        return " "


def clean_text(text):
    return lemmatize(words_only(text))


def one_hot_decoder(one_hot_label):
    return torch.argmax(one_hot_label, dim=1)


# path = Path(os.path.dirname(__file__)).joinpath('resources')


def run(string: str, resources_path: str) -> str:
    file = open(f'{resources_path}/vectorizer.pkl', 'rb')
    vectorizer = pickle.load(file)
    file.close()

    file = open(f'{resources_path}/fac_vocab.pkl', 'rb')
    fac_vocab = pickle.load(file)
    file.close()

    model = LinNet()
    model.load_state_dict(torch.load(f'{resources_path}/model.pt'))
    model.eval()

    string = clean_text(string)
    vector = vectorizer.transform([string]).todense()
    tensor = torch.from_numpy(vector)
    with torch.no_grad():
        output = model(tensor)

    decoded_output = one_hot_decoder(output)

    ad_class = fac_vocab[int(decoded_output)]

    return ad_class


# 'Куриная разделка Продам кур и куриную разделку гост и халяль по хорошей цене .Тел:'

# print(run(input('введите одно объявление \n')))

